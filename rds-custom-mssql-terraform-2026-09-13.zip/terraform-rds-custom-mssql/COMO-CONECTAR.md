# Como conectar na instancia RDS Custom for SQL Server

Deploy feito em 12/09/2026 via Terraform (`terraform-rds-custom-mssql/`), conta **286358998086**, regiao **us-east-1**, VPC homolog `vpc-0a316c1ce83bc46be` (10.2.0.0/16).

| Item | Valor |
|---|---|
| Instancia RDS | `rds-custom-mssql` (SQL Server 2022 Standard, 16.00.4265.3.v1, db.m6i.large, 100 GiB gp3) |
| Endpoint SQL | `rds-custom-mssql.cupuylwsatkg.us-east-1.rds.amazonaws.com:1433` |
| Host EC2 (Windows Server 2019) | `i-06e206fb7916e8554`, IP privado `10.2.3.6`, subnet `subnet-07780ffad76fa443c` (us-east-1b) |
| Security group | `rds-custom-mssql-sg`: 1433 e 3389 liberados para 10.2.0.0/16 e 10.1.0.0/16 |
| Credenciais | arquivo `credenciais.txt` nesta pasta (Windows Administrator e SQL admin) |
| Chave RDP (.pem) | `do-not-delete-rds-custom-rdp-privatekey-rds-custom-mssql.pem` nesta pasta |

A instancia e privada (sem IP publico). Existem dois jeitos de chegar nela: pelo tunel SSM (sem VPN, usado nos testes) ou direto pela VPN quando voce ja estiver conectado na VPC.

## Pre-requisitos no Mac

- AWS CLI com credenciais da conta 286358998086 (`export AWS_ACCESS_KEY_ID=... AWS_SECRET_ACCESS_KEY=... AWS_DEFAULT_REGION=us-east-1`, ou um profile).
- Session Manager plugin (ja instalado: `session-manager-plugin --version` -> 1.2.792.0).
- Cliente RDP: **Windows App** (ja instalado em /Applications).
- Cliente SQL de sua preferencia (Azure Data Studio, SSMS via RDP no proprio host, `sqlcmd`, DBeaver).

## Opcao 1: sem VPN, via tunel SSM Session Manager (recomendado agora)

O Session Manager cria um tunel TCP do seu Mac ate o host passando pela API da AWS. Nao precisa de IP publico, VPN nem regra de entrada no security group.

### 1a. RDP (sua preferencia)

Terminal 1, deixa aberto enquanto usar o RDP:

```bash
aws ssm start-session --target i-06e206fb7916e8554 \
  --document-name AWS-StartPortForwardingSession \
  --parameters '{"portNumber":["3389"],"localPortNumber":["13389"]}'
```

Quando aparecer `Waiting for connections...`, abra o **Windows App** e adicione um PC:

- PC name: `localhost:13389`
- Usuario: `Administrator`
- Senha: ver `credenciais.txt`

Aceite o aviso de certificado (o host usa certificado autoassinado). O login usa NLA (Network Level Authentication), entao a senha e pedida antes da tela do Windows abrir.

### 1b. SQL Server a partir do Mac

Terminal 2:

```bash
aws ssm start-session --target i-06e206fb7916e8554 \
  --document-name AWS-StartPortForwardingSession \
  --parameters '{"portNumber":["1433"],"localPortNumber":["11433"]}'
```

Depois conecte seu cliente SQL em `localhost,11433` (SQL auth, usuario `admin`, senha em `credenciais.txt`). Marque "Trust server certificate" se o cliente exigir.

### 1c. Shell PowerShell direto no host (sem RDP)

```bash
aws ssm start-session --target i-06e206fb7916e8554
```

Abre um PowerShell como `ssm-user` (administrador local). Util para copiar logs rapido. Exemplos:

```powershell
Get-ChildItem D:\rdsdbdata\Log                      # error logs e .xel do SQL Server
Get-Content D:\rdsdbdata\Log\ERROR -Tail 100
Get-WinEvent -LogName Application -MaxEvents 50     # Event Log do Windows
Write-S3Object -BucketName <bucket> -Folder D:\rdsdbdata\Log -KeyPrefix rds-custom-logs/   # enviar para S3
```

## Opcao 2: com VPN conectada na VPC

Com a VPN ja dentro da VPC, nao precisa de tunel: conecte direto no IP/endpoint privado.

- **RDP:** Windows App -> PC name `10.2.3.6` (porta 3389 padrao), usuario `Administrator`, senha em `credenciais.txt`.
- **SQL Server:** `rds-custom-mssql.cupuylwsatkg.us-east-1.rds.amazonaws.com,1433`, usuario `admin`.

Requisito: o IP de origem da VPN precisa estar dentro de `10.2.0.0/16` ou `10.1.0.0/16`. Se a VPN entregar outra faixa, adicione o CIDR em `allowed_cidr_blocks` no `terraform.tfvars` e rode `terraform apply`, ou libere manualmente as portas 1433 e 3389 no security group `rds-custom-mssql-sg`.

## Como recuperar as credenciais de novo (se perder o arquivo)

```bash
# Senha do SQL (usuario admin)
aws secretsmanager get-secret-value \
  --secret-id arn:aws:secretsmanager:us-east-1:286358998086:secret:rds-custom-mssql-master-credentials-634e8cc0-QAePj4 \
  --query SecretString --output text

# Chave privada do par RDP e senha do Administrator do Windows
aws secretsmanager get-secret-value \
  --secret-id 'do-not-delete-rds-custom-sqlserver!do-not-delete-rds-custom-rdp-privatekey-rds-custom-mssql' \
  --query SecretString --output text > rdp-key.pem && chmod 600 rdp-key.pem
aws ec2 get-password-data --instance-id i-06e206fb7916e8554 \
  --priv-launch-key rdp-key.pem --query PasswordData --output text
```

Se o host for substituido pela automacao do RDS Custom (ex: troca de classe), o instance ID muda. Descubra o novo com:

```bash
aws ec2 describe-instances \
  --filters "Name=tag:AWSRDSCustom,Values=custom-sqlserver" "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].[InstanceId,PrivateIpAddress]' --output text
```

## O que foi testado (12/09/2026)

| Teste | Resultado |
|---|---|
| SSM Agent online no host | OK (Windows Server 2019, agent 3.3.4851.0) |
| Firewall do Windows liberando 3389 (`RemoteDesktop-UserMode-In-TCP`) | OK, habilitado via SSM Run Command |
| Tunel SSM 13389 -> 3389 e handshake RDP (X.224 Connection Confirm) | OK |
| Tunel SSM 11433 -> 1433 e login SQL como `admin` a partir do Mac | OK, `admin` e sysadmin, Standard Edition |
| Shell PowerShell via `aws ssm start-session` | OK, leitura de `D:\rdsdbdata\Log` |
| `sqlcmd` local no host contra `localhost` | OK, SQL Server 2022 CU26 |

Correcao aplicada no modulo Terraform durante os testes: a policy gerenciada `AmazonRDSCustomInstanceProfileRolePolicy` nao concede `ssmmessages:CreateDataChannel` / `OpenDataChannel`, entao Session Manager (shell e port forwarding) falhava com AccessDenied. Foi adicionada uma inline policy `SessionManagerDataChannel` na role em `modules/rds-custom-mssql/iam.tf`.

## Cuidados

- Ler e copiar logs e seguro. **Nao altere** arquivos de instalacao do SQL Server, configuracao do Windows nem os agentes da AWS no host, senao a instancia entra em `unsupported-configuration` e a automacao (backup, monitoramento, recovery) para.
- Nao pare, redimensione ou termine a EC2 `i-06e206fb7916e8554` pelo console EC2. Faca tudo pelo RDS.
- Custo aproximado: USD 1,2 a 1,5 por hora (EC2 + licenca SQL Server SE + taxa RDS Custom). Quando terminar: `cd terraform-rds-custom-mssql && terraform destroy` (`skip_final_snapshot = true`, nao gera snapshot).
- Rotacione a access key `AKIAUFLCTRRDLH43HCPI` (foi colada no chat).
