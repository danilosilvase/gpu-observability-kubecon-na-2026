# Terraform: Amazon RDS Custom for SQL Server

Deploys an **Amazon RDS Custom for SQL Server** instance into an **existing VPC**.

Unlike standard (managed) RDS, RDS Custom gives you access to the underlying
EC2 host and full `sysadmin` on SQL Server. Use it when you need to collect
logs and diagnostics the managed service does not expose, for example:

- SQL Server error log directory (raw files)
- Extended Events (`.xel`) and trace (`.trc`) files
- Windows Event Logs (Application / System / Security)
- Custom log locations used by third-party or in-house tooling

## What gets created

| Resource | Notes |
|---|---|
| RDS Custom DB instance | SQL Server 2022, latest available build by default |
| DB subnet group + security group | In your existing VPC |
| KMS key | Customer-managed key (required by RDS Custom), or bring your own |
| IAM role + instance profile | Names prefixed `AWSRDSCustom` as required by the service |
| Service-linked role | `custom.rds.amazonaws.com` (optional, account-wide) |
| Secrets Manager secret | Auto-generated master credentials |
| VPC endpoints | Optional, only for VPCs with no outbound access |

## Prerequisites

1. **Terraform** >= 1.5 and **AWS CLI** configured with credentials for the target account.
2. **An existing VPC** with at least **2 subnets in different Availability Zones**.
3. **Outbound access to AWS services** from those subnets. RDS Custom automation
   requires the host to reach SSM, S3, CloudWatch, EventBridge, and Secrets Manager.
   One of:
   - Subnets route through a **NAT gateway** (typical customer setup), or
   - The VPC already has the required **VPC endpoints**, or
   - Set `create_vpc_endpoints = true` and this module creates them for you.
4. IAM permissions to create IAM roles, KMS keys, VPC endpoints, Secrets Manager
   secrets, and RDS resources.

## State backend

This deployment keeps its state in the account's shared backend (see `backend.tf`):
S3 bucket `delbank-terraform-backend`, key `rds-custom-mssql/homolog/terraform.tfstate`,
lock table `terraform-lock` (us-east-1). To continue working on it from another machine,
just unzip, export credentials for account 286358998086 and run `terraform init`; the
state is pulled from S3. Never commit or email `terraform.tfstate` files.

## How to deploy

```bash
# 1. Clone and enter the repo
git clone https://github.com/danilosilvase/terraform-rds-custom-mssql.git
cd terraform-rds-custom-mssql

# 2. Create your variables file from the example
cp terraform.tfvars.example terraform.tfvars

# 3. Edit terraform.tfvars with your values:
#    - aws_region
#    - vpc_id and subnet_ids (your existing VPC)
#    - allowed_cidr_blocks (who can reach SQL Server on 1433)

# 4. Deploy
terraform init
terraform plan
terraform apply
```

Instance creation takes **60–90 minutes**. This is normal for RDS Custom.

### Key variables

| Variable | Default | Description |
|---|---|---|
| `vpc_id` | (required) | Existing VPC ID |
| `subnet_ids` | (required) | At least 2 subnets in different AZs |
| `allowed_cidr_blocks` | (required) | CIDRs allowed to reach SQL Server |
| `sqlserver_edition` | `custom-sqlserver-se` | `-ee` (Enterprise), `-se` (Standard), `-web` (Web) |
| `engine_version` | latest | Pin a specific version if needed |
| `instance_class` | `db.m6i.large` | Smallest class supported by RDS Custom |
| `allocated_storage` | `100` | GiB (minimum 20) |
| `create_vpc_endpoints` | `false` | Set `true` only if the VPC has no NAT/outbound |
| `create_service_linked_role` | `true` | Set `false` if the account already has it |
| `publicly_accessible` | `false` | Keep `false`; `true` is for sandbox testing only |

If the account already has the RDS Custom service-linked role
(`AWSServiceRoleForRDSCustom`), set `create_service_linked_role = false`
or the apply will fail with an "already exists" error.

## After deployment

### Get the master credentials

```bash
aws secretsmanager get-secret-value \
  --secret-id "$(terraform output -raw master_secret_arn)" \
  --query SecretString --output text
```

### Connect to SQL Server

Use the endpoint from `terraform output db_endpoint` on port 1433 from a host
inside one of the `allowed_cidr_blocks`.

### Connect to the underlying host (collect your logs)

The instance host is reachable through **SSM Session Manager**, no RDP or
inbound rules needed:

```bash
# Find the EC2 instance backing the RDS Custom instance
INSTANCE_ID=$(aws ec2 describe-instances \
  --filters "Name=tag:AWSRDSCustom,Values=custom-sqlserver" \
            "Name=tag:Name,Values=/rds/rds-custom-mssql" \
            "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].InstanceId' --output text)

# Open a PowerShell session on the Windows host
aws ssm start-session --target $INSTANCE_ID
```

The exact command (with your instance identifier filled in) is also available
as a Terraform output:

```bash
terraform output connect_to_host_command
```

Typical log locations on the host:

| Logs | Location |
|---|---|
| SQL Server error logs | `D:\rdsdbdata\Log` |
| Extended Events / traces | Same directory, or wherever your session writes |
| Windows Event Logs | `Get-WinEvent -LogName Application` (PowerShell) |

To copy files off the host, upload them to S3 with PowerShell
(`Write-S3Object`) or use SSM port forwarding.

### RDP from a Mac (Windows App) through SSM port forwarding

```bash
aws ssm start-session --target <INSTANCE_ID> \
  --document-name AWS-StartPortForwardingSession \
  --parameters '{"portNumber":["3389"],"localPortNumber":["13389"]}'
```

Connect Windows App to `localhost:13389`. Use `<HOSTNAME>\Administrator` as the
username so the client does not treat it as a domain account. The Administrator
password comes from `aws ec2 get-password-data --priv-launch-key <key.pem>`, where
the key is the Secrets Manager secret named `do-not-delete-rds-custom-...-rdp-privatekey-...`.
Copy the password programmatically (`pbcopy`) rather than retyping it; `I` and `l`
are indistinguishable in most fonts. The Windows firewall rule
`RemoteDesktop-UserMode-In-TCP` must be enabled on the host (via SSM Run Command).

Note: the AWS managed policy `AmazonRDSCustomInstanceProfileRolePolicy` does not grant
`ssmmessages:CreateDataChannel` / `OpenDataChannel`, so Session Manager shells and port
forwarding fail with AccessDenied. This module adds an inline policy for those two actions.

### Stay inside the support perimeter

RDS Custom monitors the host. **Reading and copying logs is safe.** Avoid
changing SQL Server installation files, Windows configuration, or the RDS
automation agents, or the instance drops into `unsupported-configuration`
mode and pauses automation (backups, monitoring, recovery).

## Cleanup

```bash
terraform destroy
```

`skip_final_snapshot` defaults to `true`. Set it to `false` before destroying
anything that holds data you care about.

## Module usage (advanced)

The reusable module lives in `modules/rds-custom-mssql` and can be consumed
directly from your own Terraform:

```hcl
module "rds_custom_mssql" {
  source = "github.com/danilosilvase/terraform-rds-custom-mssql//modules/rds-custom-mssql"

  vpc_id              = "vpc-xxxxxxxx"
  subnet_ids          = ["subnet-aaaa", "subnet-bbbb"]
  allowed_cidr_blocks = ["10.0.0.0/16"]

  # Optional overrides
  sqlserver_edition    = "custom-sqlserver-se"
  instance_class       = "db.m6i.large"
  create_vpc_endpoints = false
}
```
