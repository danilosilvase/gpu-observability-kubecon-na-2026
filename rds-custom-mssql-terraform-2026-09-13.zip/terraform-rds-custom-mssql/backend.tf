# Remote state in the account's shared Terraform backend bucket.
# Same convention as the other projects: <project>/<environment>/terraform.tfstate
terraform {
  backend "s3" {
    bucket         = "delbank-terraform-backend"
    key            = "rds-custom-mssql/homolog/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "terraform-lock"
    encrypt        = true
  }
}
