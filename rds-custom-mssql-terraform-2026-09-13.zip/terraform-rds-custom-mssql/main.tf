# ------------------------------------------------------------------
# RDS Custom for SQL Server - root configuration
#
# Thin wrapper around the reusable module. Customers deploying to
# their own (standalone) accounts only need to:
#   1. cp terraform.tfvars.example terraform.tfvars
#   2. Fill in their existing VPC / subnets / allowed CIDRs
#   3. terraform init && terraform apply
# ------------------------------------------------------------------

module "rds_custom_mssql" {
  source = "./modules/rds-custom-mssql"

  # Existing customer network
  vpc_id              = var.vpc_id
  subnet_ids          = var.subnet_ids
  allowed_cidr_blocks = var.allowed_cidr_blocks

  # Naming
  name_prefix = var.name_prefix
  tags        = var.tags

  # Engine
  sqlserver_edition = var.sqlserver_edition
  engine_version    = var.engine_version
  instance_class    = var.instance_class

  # Storage
  allocated_storage = var.allocated_storage

  # Access
  publicly_accessible = var.publicly_accessible
  enable_rdp_access   = var.enable_rdp_access

  # Networking prerequisites
  create_vpc_endpoints = var.create_vpc_endpoints

  # Account-level prerequisites
  create_service_linked_role = var.create_service_linked_role

  # Lifecycle
  skip_final_snapshot = var.skip_final_snapshot
}
