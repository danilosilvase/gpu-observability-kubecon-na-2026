# ------------------------------------------------------------------
# Optional VPC endpoints for RDS Custom automation
#
# RDS Custom requires the instance to reach these AWS services:
#   ssm, ssmmessages, ec2, ec2messages, events, logs, monitoring,
#   secretsmanager (interface endpoints) and s3 (gateway endpoint).
#
# If the VPC already provides outbound access (NAT gateway or existing
# endpoints), leave create_vpc_endpoints = false. Enable it for fully
# private VPCs with no outbound path.
#
# Note: the S3 gateway endpoint is associated with ALL route tables in
# the VPC so it covers whichever tables the DB subnets use.
# ------------------------------------------------------------------

locals {
  interface_endpoint_services = var.create_vpc_endpoints ? toset([
    "ssm",
    "ssmmessages",
    "ec2",
    "ec2messages",
    "events",
    "logs",
    "monitoring",
    "secretsmanager",
  ]) : toset([])
}

data "aws_vpc" "this" {
  id = var.vpc_id
}

data "aws_route_tables" "vpc" {
  count  = var.create_vpc_endpoints ? 1 : 0
  vpc_id = var.vpc_id
}

data "aws_vpc_endpoint_service" "interface" {
  for_each = local.interface_endpoint_services

  service      = each.value
  service_type = "Interface"
}

data "aws_vpc_endpoint_service" "s3_gateway" {
  count = var.create_vpc_endpoints ? 1 : 0

  service      = "s3"
  service_type = "Gateway"
}

resource "aws_security_group" "vpc_endpoints" {
  count = var.create_vpc_endpoints ? 1 : 0

  name        = "${var.name_prefix}-vpce-sg"
  description = "HTTPS to VPC endpoints for RDS Custom automation"
  vpc_id      = var.vpc_id
  tags        = var.tags
}

resource "aws_vpc_security_group_ingress_rule" "vpce_https" {
  count = var.create_vpc_endpoints ? 1 : 0

  security_group_id = aws_security_group.vpc_endpoints[0].id
  description       = "HTTPS from within the VPC"
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"
  cidr_ipv4         = data.aws_vpc.this.cidr_block
}

resource "aws_vpc_endpoint" "interface" {
  for_each = local.interface_endpoint_services

  vpc_id              = var.vpc_id
  service_name        = data.aws_vpc_endpoint_service.interface[each.key].service_name
  vpc_endpoint_type   = "Interface"
  subnet_ids          = var.subnet_ids
  security_group_ids  = [aws_security_group.vpc_endpoints[0].id]
  private_dns_enabled = true

  tags = merge(var.tags, { Name = "${var.name_prefix}-${each.key}" })
}

resource "aws_vpc_endpoint" "s3" {
  count = var.create_vpc_endpoints ? 1 : 0

  vpc_id            = var.vpc_id
  service_name      = data.aws_vpc_endpoint_service.s3_gateway[0].service_name
  vpc_endpoint_type = "Gateway"
  route_table_ids   = data.aws_route_tables.vpc[0].ids

  tags = merge(var.tags, { Name = "${var.name_prefix}-s3" })
}
