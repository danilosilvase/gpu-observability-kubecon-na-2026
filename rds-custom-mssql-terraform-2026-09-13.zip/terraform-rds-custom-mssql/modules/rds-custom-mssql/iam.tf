# ------------------------------------------------------------------
# IAM for RDS Custom
#
# RDS Custom requires an EC2 instance profile whose name starts with
# "AWSRDSCustom". The AWS-managed policy
# AmazonRDSCustomInstanceProfileRolePolicy grants the automation
# permissions the host needs (SSM, S3, CloudWatch, Secrets Manager, KMS).
# ------------------------------------------------------------------

data "aws_partition" "current" {}

data "aws_iam_policy_document" "rds_custom_assume" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "rds_custom" {
  # Name MUST begin with AWSRDSCustom
  name               = "AWSRDSCustomRole-${var.name_prefix}"
  assume_role_policy = data.aws_iam_policy_document.rds_custom_assume.json
  tags               = var.tags
}

resource "aws_iam_role_policy_attachment" "rds_custom_managed" {
  role       = aws_iam_role.rds_custom.name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/AmazonRDSCustomInstanceProfileRolePolicy"
}

resource "aws_iam_instance_profile" "rds_custom" {
  # Name MUST begin with AWSRDSCustom
  name = "AWSRDSCustomInstanceProfile-${var.name_prefix}"
  role = aws_iam_role.rds_custom.name
  tags = var.tags
}

# Service-linked role for RDS Custom (account-wide, created once).
# Disable via create_service_linked_role = false if it already exists.
resource "aws_iam_service_linked_role" "rds_custom" {
  count            = var.create_service_linked_role ? 1 : 0
  aws_service_name = "custom.rds.amazonaws.com"
}

# The AWS-managed policy only grants the ssmmessages *ControlChannel*
# actions, which is enough for Run Command but NOT for Session Manager
# (interactive shell or port forwarding). Session Manager also needs
# the *DataChannel* actions, otherwise sessions fail with
# "not authorized to perform: ssmmessages:CreateDataChannel".
data "aws_iam_policy_document" "ssm_session_manager" {
  statement {
    sid = "SessionManagerDataChannel"
    actions = [
      "ssmmessages:CreateDataChannel",
      "ssmmessages:OpenDataChannel",
    ]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "ssm_session_manager" {
  name   = "SessionManagerDataChannel"
  role   = aws_iam_role.rds_custom.id
  policy = data.aws_iam_policy_document.ssm_session_manager.json
}
