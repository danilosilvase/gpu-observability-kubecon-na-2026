# ------------------------------------------------------------------
# KMS key for RDS Custom
#
# RDS Custom requires a customer-managed symmetric KMS key.
# The default aws/rds key is NOT supported.
# A key is created unless an existing one is passed via kms_key_arn.
# ------------------------------------------------------------------

locals {
  create_kms_key = var.kms_key_arn == ""
  kms_key_arn    = local.create_kms_key ? aws_kms_key.rds_custom[0].arn : var.kms_key_arn
}

resource "aws_kms_key" "rds_custom" {
  count = local.create_kms_key ? 1 : 0

  description             = "KMS key for RDS Custom SQL Server (${var.name_prefix})"
  deletion_window_in_days = 14
  enable_key_rotation     = true
  tags                    = var.tags
}

resource "aws_kms_alias" "rds_custom" {
  count = local.create_kms_key ? 1 : 0

  name          = "alias/${var.name_prefix}"
  target_key_id = aws_kms_key.rds_custom[0].key_id
}
