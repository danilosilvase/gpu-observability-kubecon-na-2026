# ------------------------------------------------------------------
# RDS Custom for SQL Server
#
# RDS Custom gives you access to the underlying EC2 host and full
# sysadmin on SQL Server, so you can collect logs the managed RDS
# service does not expose (extended events files, custom trace files,
# Windows event logs, SQL Server error log directory, etc.).
# ------------------------------------------------------------------

# Resolve the latest engine version automatically unless one is pinned
data "aws_rds_engine_version" "custom_sqlserver" {
  engine  = var.sqlserver_edition
  version = var.engine_version != "" ? var.engine_version : null
  latest  = var.engine_version == "" ? true : null
}

resource "random_password" "master" {
  length           = 24
  special          = true
  override_special = "!#$%^&*()-_=+"
}

# Unique suffix so the secret name never collides with a
# previously-deleted secret still in its recovery window
resource "random_id" "secret_suffix" {
  byte_length = 4
}

# Keep the master password retrievable (RDS Custom does not support
# the managed master password / Secrets Manager integration flag)
resource "aws_secretsmanager_secret" "master" {
  name                    = "${var.name_prefix}-master-credentials-${random_id.secret_suffix.hex}"
  kms_key_id              = local.kms_key_arn
  recovery_window_in_days = 7
  tags                    = var.tags
}

resource "aws_secretsmanager_secret_version" "master" {
  secret_id = aws_secretsmanager_secret.master.id
  secret_string = jsonencode({
    username = var.master_username
    password = random_password.master.result
  })
}

resource "aws_db_instance" "custom_sqlserver" {
  identifier = var.name_prefix

  # --- Engine ---
  engine         = var.sqlserver_edition
  engine_version = data.aws_rds_engine_version.custom_sqlserver.version
  instance_class = var.instance_class

  # --- RDS Custom requirements ---
  custom_iam_instance_profile = aws_iam_instance_profile.rds_custom.name
  kms_key_id                  = local.kms_key_arn
  storage_encrypted           = true

  # Not supported / must be disabled on RDS Custom
  auto_minor_version_upgrade = false
  multi_az                   = false

  # --- Storage ---
  allocated_storage = var.allocated_storage
  storage_type      = var.storage_type

  # --- Credentials ---
  username = var.master_username
  password = random_password.master.result
  port     = var.db_port

  # --- Networking ---
  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.rds_custom.id]
  publicly_accessible    = var.publicly_accessible

  # --- Backups / lifecycle ---
  backup_retention_period = var.backup_retention_period
  backup_window           = "03:00-04:00"
  maintenance_window      = "sun:05:00-sun:06:00"
  skip_final_snapshot     = var.skip_final_snapshot
  apply_immediately       = true

  tags = var.tags

  depends_on = [
    aws_iam_role_policy_attachment.rds_custom_managed,
    aws_iam_service_linked_role.rds_custom,
    # Endpoints (when enabled) must exist before RDS Custom automation starts
    aws_vpc_endpoint.interface,
    aws_vpc_endpoint.s3,
  ]

  timeouts {
    create = "4h"
    update = "4h"
    delete = "4h"
  }
}
