# ------------------------------------------------------------------
# Networking: DB subnet group + security group (in an existing VPC)
# ------------------------------------------------------------------

resource "aws_db_subnet_group" "this" {
  name       = "${var.name_prefix}-subnet-group"
  subnet_ids = var.subnet_ids
  tags       = var.tags
}

resource "aws_security_group" "rds_custom" {
  name        = "${var.name_prefix}-sg"
  description = "Access to RDS Custom SQL Server"
  vpc_id      = var.vpc_id
  tags        = var.tags
}

resource "aws_vpc_security_group_ingress_rule" "sqlserver" {
  for_each = toset(var.allowed_cidr_blocks)

  security_group_id = aws_security_group.rds_custom.id
  description       = "SQL Server"
  from_port         = var.db_port
  to_port           = var.db_port
  ip_protocol       = "tcp"
  cidr_ipv4         = each.value
}

# Optional RDP access to the underlying Windows host.
# SSM Session Manager is the recommended path and needs no inbound rule.
resource "aws_vpc_security_group_ingress_rule" "rdp" {
  for_each = var.enable_rdp_access ? toset(var.allowed_cidr_blocks) : []

  security_group_id = aws_security_group.rds_custom.id
  description       = "RDP to underlying host"
  from_port         = 3389
  to_port           = 3389
  ip_protocol       = "tcp"
  cidr_ipv4         = each.value
}

# Outbound access is required by RDS Custom automation
# (SSM, S3, CloudWatch, Secrets Manager, EC2 messages).
resource "aws_vpc_security_group_egress_rule" "all" {
  security_group_id = aws_security_group.rds_custom.id
  description       = "Outbound for RDS Custom automation"
  ip_protocol       = "-1"
  cidr_ipv4         = "0.0.0.0/0"
}
