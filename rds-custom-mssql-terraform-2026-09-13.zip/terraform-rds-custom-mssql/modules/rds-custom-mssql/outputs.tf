output "db_endpoint" {
  description = "SQL Server endpoint"
  value       = aws_db_instance.custom_sqlserver.endpoint
}

output "db_instance_identifier" {
  description = "DB instance identifier"
  value       = aws_db_instance.custom_sqlserver.identifier
}

output "engine_version" {
  description = "Engine version that was deployed"
  value       = aws_db_instance.custom_sqlserver.engine_version_actual
}

output "db_resource_id" {
  description = "DB instance resource ID (used to find the underlying EC2 host)"
  value       = aws_db_instance.custom_sqlserver.resource_id
}

output "master_secret_arn" {
  description = "Secrets Manager secret holding the master credentials"
  value       = aws_secretsmanager_secret.master.arn
}

output "security_group_id" {
  description = "Security group attached to the instance"
  value       = aws_security_group.rds_custom.id
}

output "kms_key_arn" {
  description = "KMS key used for storage encryption"
  value       = local.kms_key_arn
}

output "connect_to_host_command" {
  description = "Find the underlying EC2 instance and open an SSM session to the Windows host"
  value       = <<-EOT
    INSTANCE_ID=$(aws ec2 describe-instances \
      --filters "Name=tag:AWSRDSCustom,Values=custom-sqlserver" \
                "Name=tag:Name,Values=/rds/${aws_db_instance.custom_sqlserver.identifier}" \
                "Name=instance-state-name,Values=running" \
      --query 'Reservations[].Instances[].InstanceId' --output text)
    aws ssm start-session --target $INSTANCE_ID
  EOT
}
