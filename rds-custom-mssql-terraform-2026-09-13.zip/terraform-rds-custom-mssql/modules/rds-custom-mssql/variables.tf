# ------------------------------------------------------------------
# Required inputs (customer-provided, existing VPC)
# ------------------------------------------------------------------

variable "vpc_id" {
  description = "Existing VPC ID where the RDS Custom instance will be deployed"
  type        = string
}

variable "subnet_ids" {
  description = "Existing subnet IDs for the DB subnet group (at least 2, in different AZs). Subnets need outbound access to AWS services (NAT gateway, VPC endpoints, or public subnets with publicly_accessible=true) for RDS Custom automation."
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) >= 2
    error_message = "Provide at least 2 subnet IDs in different Availability Zones."
  }
}

variable "allowed_cidr_blocks" {
  description = "CIDR blocks allowed to reach SQL Server (port 1433) and RDP (3389 if enabled)"
  type        = list(string)
}

# ------------------------------------------------------------------
# Naming
# ------------------------------------------------------------------

variable "name_prefix" {
  description = "Prefix used for naming resources"
  type        = string
  default     = "rds-custom-mssql"
}

variable "tags" {
  description = "Tags applied to all resources"
  type        = map(string)
  default     = {}
}

# ------------------------------------------------------------------
# Engine
# ------------------------------------------------------------------

variable "sqlserver_edition" {
  description = "RDS Custom SQL Server engine: custom-sqlserver-ee (Enterprise), custom-sqlserver-se (Standard), custom-sqlserver-web (Web)"
  type        = string
  default     = "custom-sqlserver-se"

  validation {
    condition     = contains(["custom-sqlserver-ee", "custom-sqlserver-se", "custom-sqlserver-web"], var.sqlserver_edition)
    error_message = "Must be one of: custom-sqlserver-ee, custom-sqlserver-se, custom-sqlserver-web."
  }
}

variable "engine_version" {
  description = "Specific engine version. Leave empty to automatically use the latest available version."
  type        = string
  default     = ""
}

variable "instance_class" {
  description = "Instance class. Smallest supported by RDS Custom for SQL Server is db.m6i.large / db.m5.large (2 vCPU, 8 GB); also supports r5/r5b/r6i/x2iedn families."
  type        = string
  default     = "db.m6i.large"
}

# ------------------------------------------------------------------
# Storage
# ------------------------------------------------------------------

variable "allocated_storage" {
  description = "Allocated storage in GiB"
  type        = number
  default     = 100
}

variable "storage_type" {
  description = "Storage type (gp2, gp3, or io1)"
  type        = string
  default     = "gp3"
}

# ------------------------------------------------------------------
# Access / credentials
# ------------------------------------------------------------------

variable "master_username" {
  description = "Master username for SQL Server"
  type        = string
  default     = "admin"
}

variable "db_port" {
  description = "SQL Server port"
  type        = number
  default     = 1433
}

variable "publicly_accessible" {
  description = "Give the instance a public IP. Only for sandbox/testing in public subnets without NAT; keep false for customer deployments in private subnets."
  type        = bool
  default     = false
}

variable "enable_rdp_access" {
  description = "Open port 3389 for RDP access to the underlying host (SSM Session Manager works without this)"
  type        = bool
  default     = false
}

# ------------------------------------------------------------------
# Encryption
# ------------------------------------------------------------------

variable "kms_key_arn" {
  description = "ARN of an existing customer-managed symmetric KMS key. Leave empty to create one. The AWS-managed aws/rds key is NOT supported by RDS Custom."
  type        = string
  default     = ""
}

# ------------------------------------------------------------------
# Account-level prerequisites
# ------------------------------------------------------------------

variable "create_vpc_endpoints" {
  description = "Create the VPC endpoints RDS Custom automation requires (s3 gateway + ssm/ssmmessages/ec2/ec2messages/events/logs/monitoring/secretsmanager interface endpoints). Leave false if the VPC already has outbound access via NAT or existing endpoints."
  type        = bool
  default     = false
}

variable "create_service_linked_role" {
  description = "Create the RDS Custom service-linked role (custom.rds.amazonaws.com). Set to false if the account already has it (it is account-wide and created once)."
  type        = bool
  default     = true
}

# ------------------------------------------------------------------
# Backups / lifecycle
# ------------------------------------------------------------------

variable "backup_retention_period" {
  description = "Backup retention in days"
  type        = number
  default     = 7
}

variable "skip_final_snapshot" {
  description = "Skip the final snapshot on destroy (set false for anything holding real data)"
  type        = bool
  default     = true
}
