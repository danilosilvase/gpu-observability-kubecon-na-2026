output "db_endpoint" {
  description = "SQL Server endpoint"
  value       = module.rds_custom_mssql.db_endpoint
}

output "engine_version" {
  description = "Engine version that was deployed"
  value       = module.rds_custom_mssql.engine_version
}

output "db_resource_id" {
  description = "DB instance resource ID"
  value       = module.rds_custom_mssql.db_resource_id
}

output "master_secret_arn" {
  description = "Secrets Manager secret holding the master credentials"
  value       = module.rds_custom_mssql.master_secret_arn
}

output "connect_to_host_command" {
  description = "Find the underlying EC2 instance and open an SSM session to the Windows host"
  value       = module.rds_custom_mssql.connect_to_host_command
}
