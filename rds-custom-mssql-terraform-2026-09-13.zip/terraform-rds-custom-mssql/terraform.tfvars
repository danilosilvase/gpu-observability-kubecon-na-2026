aws_region = "us-east-1"

# Homolog (staging) VPC 10.2.0.0/16, private subnets in us-east-1a / us-east-1b, egress via NAT
vpc_id     = "vpc-0a316c1ce83bc46be"
subnet_ids = ["subnet-0911da03f38fbb72d", "subnet-07780ffad76fa443c"]

# Reach SQL Server from anywhere inside the homolog and prod VPCs
allowed_cidr_blocks = ["10.2.0.0/16", "10.1.0.0/16"]

name_prefix       = "rds-custom-mssql"
sqlserver_edition = "custom-sqlserver-se"
engine_version    = ""
instance_class    = "db.m6i.large"
allocated_storage = 100

publicly_accessible = false
enable_rdp_access   = true

# VPC already has NAT egress
create_vpc_endpoints = false

# AWSServiceRoleForRDSCustom already exists in account 286358998086
create_service_linked_role = false

skip_final_snapshot = true

tags = {
  Project     = "rds-custom-mssql"
  Environment = "homolog"
  ManagedBy   = "terraform"
}
