variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "us-east-1"
}

variable "vpc_id" {
  description = "Existing VPC ID where the RDS Custom instance will be deployed"
  type        = string
}

variable "subnet_ids" {
  description = "Existing subnet IDs for the DB subnet group (at least 2, in different AZs)"
  type        = list(string)
}

variable "allowed_cidr_blocks" {
  description = "CIDR blocks allowed to reach SQL Server (port 1433) and RDP (3389 if enabled)"
  type        = list(string)
}

variable "name_prefix" {
  description = "Prefix used for naming resources"
  type        = string
  default     = "rds-custom-mssql"
}

variable "sqlserver_edition" {
  description = "custom-sqlserver-ee (Enterprise), custom-sqlserver-se (Standard), custom-sqlserver-web (Web)"
  type        = string
  default     = "custom-sqlserver-se"
}

variable "engine_version" {
  description = "Specific engine version. Leave empty to use the latest available."
  type        = string
  default     = ""
}

variable "instance_class" {
  description = "Instance class (smallest supported: db.m6i.large)"
  type        = string
  default     = "db.m6i.large"
}

variable "allocated_storage" {
  description = "Allocated storage in GiB"
  type        = number
  default     = 100
}

variable "publicly_accessible" {
  description = "Give the instance a public IP (sandbox/testing only)"
  type        = bool
  default     = false
}

variable "enable_rdp_access" {
  description = "Open port 3389 for RDP to the underlying host"
  type        = bool
  default     = false
}

variable "create_vpc_endpoints" {
  description = "Create the VPC endpoints RDS Custom requires (set true for VPCs without NAT/outbound access)"
  type        = bool
  default     = false
}

variable "create_service_linked_role" {
  description = "Create the RDS Custom service-linked role (set false if the account already has it)"
  type        = bool
  default     = true
}

variable "skip_final_snapshot" {
  description = "Skip the final snapshot on destroy"
  type        = bool
  default     = true
}

variable "tags" {
  description = "Tags applied to all resources"
  type        = map(string)
  default     = {}
}
